##References


*	Bonnie Owens, Open Source Food. (2009, December). Mamas Recipe The Best Chocolate Chip Cookies. Retrieved September 22, 2013, from: http://www.opensourcefood.com/people/Amanori/recipes/mamas-recipe-the-best-chocolate-chip-cookies