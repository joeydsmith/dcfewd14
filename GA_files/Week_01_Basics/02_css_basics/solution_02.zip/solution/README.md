##References


*	Andrew Gold, Lyrics On Demand. Thank You for Being a Friend. Retrieved September 22, 2013, from: http://www.lyricsondemand.com/tvthemes/

*	Wikipedia. (2013, October). The Golden Girls. Retrieved September 22, 2013, from: http://en.wikipedia.org/wiki/The_Golden_Girls

		
*	Google image.(November 2001). Retrieved September 22, 2013, from http://scm-l3.technorati.com/11/03/07/28727/Betty-White.jpg.